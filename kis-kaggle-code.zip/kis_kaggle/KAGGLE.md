# Chuẩn bị video bằng Kaggle GPU

Hai bản ZIP dùng cho hai mục đích:

| ZIP trong `dist/` | Mục đích |
|---|---|
| `kis-kaggle-code.zip` | Video mới: keyframes, SigLIP features, objects, caption InternVL, caption index, validation |
| `kis-kaggle-keyframes-caption.zip` | L19/L20: chạy lại keyframes và caption InternVL |

Cả hai mặc định dùng **OpenGVLab/InternVL3_5-1B-HF**, caption tối đa 96 tokens,
batch 16, BF16 native hoặc FP32, guard NaN/Inf và phát hiện token lặp.

## 1. Đóng gói code trên máy Windows

Trong thư mục repository:

```powershell
python package_kaggle.py
```

Upload `dist/kis-kaggle-code.zip` thành Kaggle Dataset (ví dụ `kis-code`).
Tạo dataset khác chứa video (ví dụ `kis-videos`), với tên file `L20_V002.mp4`,
`L20_V003.mp4`... Thêm cả hai dataset vào notebook bằng **Add Input**.
Kaggle có thể giải nén ZIP khi upload; cell bên dưới hỗ trợ cả ZIP và folder đã giải nén.

## 2. Cấu hình notebook

Trong Settings bật **Internet** và chọn **GPU T4/P100** theo quyền/quota hiện có.
Pipeline dùng một GPU (`cuda:0`), không tự chia workload qua hai GPU.
Không cần Docker, Milvus, API key Gemini hay SSH để tạo artifact.

### Cell 1 — lấy code và cài dependencies

```python
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

CODE_INPUT = Path('/kaggle/input/kis-code')      # sửa theo Add Input
CODE_DIR = Path('/kaggle/working/kis_kaggle')

archives = list(CODE_INPUT.rglob('kis-kaggle-code.zip'))
if archives:
    with zipfile.ZipFile(archives[0]) as archive:
        archive.extractall('/kaggle/working')
else:
    candidates = list(CODE_INPUT.rglob('kaggle_prepare.py'))
    assert len(candidates) == 1, candidates
    shutil.copytree(candidates[0].parent, CODE_DIR, dirs_exist_ok=True)

subprocess.run([
    sys.executable, '-m', 'pip', 'install',
    '-r', str(CODE_DIR / 'requirements-kaggle.txt'),
], check=True)
```

Giữ bản CUDA torch/torchvision do Kaggle cài sẵn; không cài requirements CPU cũ
hoặc toàn bộ `requirements.txt` trong Kaggle. Nếu pip yêu cầu restart session,
restart rồi chạy cell cấu hình bên dưới. Dependencies model có thể phụ thuộc
phiên bản image Kaggle; nếu gặp conflict hãy gửi log thay vì tự thay CUDA wheel.

### Cell 2 — cấu hình và kiểm tra GPU

```python
from pathlib import Path
import subprocess
import sys
import torch

CODE_DIR = Path('/kaggle/working/kis_kaggle')
VIDEO_DIR = Path('/kaggle/input/kis-videos')      # sửa theo Add Input
VIDEO_IDS = ['L20_V002']                         # None: toàn bộ video
SMOKE_MODE = True
OUTPUT_ROOT = Path('/kaggle/working/kis_output')

assert torch.cuda.is_available(), 'Bật GPU accelerator và restart session'
print(torch.__version__, torch.cuda.get_device_name(0))
```

### Cell 3 — chạy pipeline

```python
command = [
    sys.executable, '-u', str(CODE_DIR / 'kaggle_prepare.py'),
    '--video-dir', str(VIDEO_DIR),
    '--output-root', str(OUTPUT_ROOT),
    '--visual-batch', '8', '--object-batch', '8', '--caption-batch', '16',
    '--seed', '42',
]
for video_id in VIDEO_IDS or []:
    command += ['--video-id', video_id]
if SMOKE_MODE:
    command += ['--smoke-seconds', '12']
subprocess.run(command, check=True)
```

Chạy thử xong, đổi `SMOKE_MODE=False` ở cell 2 rồi chạy lại cell 2 và 3 để xử lý
full video. Runner chạy trong process riêng nên mỗi lần dùng đúng cấu hình mới,
không giữ giới hạn 12 giây từ kernel cũ. Smoke output được tách riêng khỏi full output.

Keyframes lấy frame 0 rồi random gap **80–160 frame**, seed 42.
Tách video dùng CPU; SigLIP, SSDLite objects, InternVL caption và MiniLM dùng GPU.
Caption là đoạn tiếng Anh ngắn tập trung vào chủ thể/hành động/thuộc tính nhìn thấy,
batch mặc định 16, model/revision pinned. Compute tự chọn BF16 native hoặc FP32;
mặc định không quantize model 1B.
Thêm `--caption-4bit` để ép dùng NF4, hoặc
`--caption-backend qwen` / `blip` để chọn các backend cũ. Xem [CAPTION_V2.md](CAPTION_V2.md).
Các stage giải phóng model/cache tuần tự để giảm VRAM.
Caption tự giảm batch nếu CUDA OOM. Có thể dùng `--caption-4bit` để giảm VRAM;
visual/object OOM thì giảm batch tương ứng xuống 4 và chạy lại.
Objects/captions có checkpoint, visual features được publish sau khi xong mỗi video.

Khi output đã có caption model cũ, dùng `--restart-captions` một lần để backup
và sinh lại caption bằng InternVL, hoặc chọn output root mới. Bỏ flag này khi
resume bình thường. Các stage khác vẫn tái sử dụng artifact cùng config.

Nếu chỉ cần keyframes và caption, dùng ZIP riêng
`dist/kis-kaggle-keyframes-caption.zip` theo `KAGGLE_KEYFRAMES_CAPTION.md`.

## 3. Output và tải về

Full output nằm tại `/kaggle/working/kis_output/`:

```text
data/<group>/<video_id>/001.jpg
mapping/<group>/<video_id>.csv
clip-features-32/<group>/<video_id>.npy
objects/<video_id>/001.json
caption_generator/<group>/<video_id>.json
caption_mapping/<group>/<video_id>.json
index/<group>/<video_id>.index
index/<group>/<video_id>.meta.json
preparation/<group>/<video_id>.json
```

Runner validate đầy đủ schema, checksum, count và identity, rồi tạo:

```text
/kaggle/working/kis_output-artifacts.zip
```

Tải ZIP ở phần Output; **Save Version / Save & Run All** để lưu output trước khi
phiên Kaggle bị reset. File trong phiên working không phải checkpoint lâu dài
nếu chưa lưu output. Muốn resume phiên khác, upload artifact đã lưu thành Dataset
và copy vào `/kaggle/working/kis_output` trước khi chạy cùng source/config.

Giải nén ZIP tại thư mục chính `KISBranche` trên máy bạn. ZIP chứa các folder
artifact trực tiếp, không chứa code hay folder lồng `kis_output`. Nếu video_id
đã tồn tại, kiểm tra trước khi ghi đè. Sau đó tại máy chạy retrieval:

```powershell
python build_milvus.py rebuild
```

Khởi động lại web app. Objects có schema 5 field giống provider, chuỗi score/box,
Open Images MID/label được ánh xạ từ COCO; tập nhãn/model detector vẫn khác provider.
