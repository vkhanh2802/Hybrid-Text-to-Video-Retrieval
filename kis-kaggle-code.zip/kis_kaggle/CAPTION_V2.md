# Build caption: InternVL3.5-1B-HF

## Thiết kế

Backend mặc định `internvl` dùng **OpenGVLab/InternVL3_5-1B-HF** với revision
`9191dbccf312b537016f041b25d61c72e7c5c9f3` đã pin trong `model_manifest.json`.
Model chỉ nhận ảnh và prompt chung; query tìm kiếm, caption cũ và ground truth
không được đưa vào prompt sinh caption.

Caption mặc định là đoạn tiếng Anh ngắn, 2-3 câu, hướng tới tối đa 50 từ và
giới hạn cứng **96 output tokens**. Processor dùng ảnh 448 và `max_patches=2`.
Không bật reasoning; output chứa reasoning hoặc token rác bị từ chối.

Output giữ các field tương thích `caption`, `details`, `retrieval_text`, identity
và `image_path`. Các field bổ sung:

- `caption`: mô tả ngắn có chủ thể/hành động/màu sắc/vị trí nhìn thấy trong ảnh.
- `caption_generation`: backend, model/revision, prompt hash, kích thước ảnh,
  precision, schema và renderer version.
- `image_sha256`: checksum ảnh nguồn để kiểm tra resume.
- `generation_seconds`: thời gian batch thành công chia cho số ảnh trong batch.
- `generation_batch_size`: số ảnh trong batch inference đã thành công.

Với InternVL V3, `details` là chuỗi rỗng, `vqa_answers` là `{}` và không tạo
`visual_description` giả. `retrieval_text` được dựng từ caption và OCR nếu có.
Audit/index loader hỗ trợ BLIP V1, Qwen structured V2 và InternVL dense V3.

Prompt yêu cầu giữ thuộc tính với đúng người, phân biệt backdrop, không đoán
nguyên liệu/thứ tự sự kiện và bỏ qua TV ticker/logo. Đây là yêu cầu với model,
không phải bảo đảm mọi mô tả đều đúng; cần đánh giá bằng ảnh và retrieval.
Checkpoint atomically sau mỗi ảnh đã sinh trong batch; model/prompt/precision
và checksum ảnh phải khớp khi resume.

## Chạy trên máy hiện tại

Môi trường retrieval đã có các dependencies cần thiết, dùng HF class native,
không chạy remote Python code từ model repository. BF16 khi GPU hỗ trợ native,
FP32 trên T4/P100. Mặc định không quantize model 1B; `--caption-4bit` hoặc
`--use-4bit` là tùy chọn tiết kiệm VRAM. Tự giảm batch khi CUDA OOM.

```powershell
conda activate focusguard_ai
$env:OMP_NUM_THREADS = "4"
$env:MKL_NUM_THREADS = "4"
# Khi model đã có đầy đủ trong cache:
$env:HF_HUB_OFFLINE = "1"

# Thử một video; caption InternVL nằm trong output riêng.
python caption_generator.py --input-root . --output-root caption_internvl --video-id L19_V015 --backend internvl --device cuda --batch-size 16

# Dựng FAISS/MiniLM + mapping + SHA-256 manifest từ caption V2.
python build_caption_index.py --project-root caption_internvl --mapping-dir mapping --device cpu
```

Bỏ `--video-id` để xử lý toàn bộ video có keyframe trong `data/`. Có thể lặp lại
`--video-id` để chọn một số video. Chạy lại cùng lệnh để resume. Muốn đổi prompt,
precision hoặc model, chọn output root mới; generator từ chối trộn phiên bản.
Các backend cũ: `--backend qwen` cho JSON V2, `--backend blip` cho BLIP + VQA.

## Dùng bộ caption mới trong web

Sau khi build xong **đủ caption/index cho phạm vi muốn tìm kiếm**:

```powershell
$env:KIS_CAPTION_ROOT = "caption_internvl"
$env:KIS_VIDEO_GROUPS = "L19,L20"
$env:KIS_RETRIEVAL_PROFILE = "upgraded"
python web_app.py
```

`KIS_CAPTION_ROOT` trỏ đến root chứa ba folder `caption_generator/`,
`caption_mapping/`, `index/`. Ảnh và visual features vẫn ở dataset nguồn.
API status/search trả `caption_artifact_root` để xác nhận đang dùng phiên bản nào.
Web dùng live Gemini nên cần `GEMINI_API_KEY` như trước.

## Kaggle GPU

Hai ZIP đều mặc định `--caption-backend internvl --caption-batch 16`.
Có guard NaN/Inf, dừng token lặp và lưu dtype/model/revision trong checkpoint.
Giữ `--caption-backend qwen` hoặc `blip` để chạy các backend cũ.

Hai runner Kaggle mặc định `--caption-batch 16`. Model gom các ảnh thành batch,
left-pad prompt, gọi generate một lần rồi ghép output theo đúng thứ tự ảnh.
Nếu OOM, batch được chia nhỏ và checkpoint
được lưu sau mỗi sub-batch thành công. Batch hiệu dụng phụ thuộc VRAM và kích
thước ảnh; log `[InternVL batch] size=...` cho biết batch đang thực sự chạy.

ZIP chỉ chạy keyframes + caption: `python package_kaggle.py --profile keyframes-caption`.
File mới: `dist/kis-kaggle-keyframes-caption.zip`; xem `KAGGLE_KEYFRAMES_CAPTION.md`.

Với dữ liệu đã có caption Qwen/BLIP, chọn output root mới hoặc thêm
`--restart-captions` **một lần** vào lệnh runner Kaggle. Caption cũ được chuyển vào
`preparation/caption_backups/`, keyframes được tái sử dụng và chỉ caption được
sinh lại. Sau khi đổi model, bỏ flag này để resume bình thường. Full runner sẽ
build lại text index sau khi sinh caption xong.

## Pilot A/B

`benchmark_light_caption.py --backend internvl --batch-size 16` chạy probe model
mới trên 8 ảnh L19/L20. Thời gian local không thay thế benchmark trên GPU Kaggle.
Các lệnh bên dưới là pilot Qwen V2 trước đây, không được dùng làm kết quả đo
chất lượng InternVL V3:

```powershell
python benchmark_caption_v2.py generate --smoke
python benchmark_caption_v2.py generate
python benchmark_caption_v2.py index
python benchmark_caption_v2.py retrieve
python benchmark_caption_v2.py vlm
python benchmark_caption_v2.py report
```

Pilot cố định tại `benchmarks/caption_v2_pilot.json`: 212 ảnh/59 video, gồm
anchor ±2 keyframe, top-2 candidate V1 và một midpoint/video. Có thêm 8 query mới
được viết từ ảnh trước khi sinh V2 trong `benchmarks/caption_v2_fresh.json`.

Hai phép đo có phạm vi khác nhau:

1. **Common pool:** cả ba nhánh search cùng 212 ảnh; caption của mọi candidate
   được so sánh V1/V2. Đo retrieval để kiểm tra khả năng phân biệt trong pilot.
2. **Partial overlay:** search toàn bộ 15.938 frame L19/L20, thay đúng 212 caption
   bằng V2. Giữ nguyên SigLIP/Milvus, query variants, weights, nprobe=128, depth=100;
   Qwen rerank cùng budget=20. Đây là phép đo cập nhật một phần corpus, chưa phải
   kết quả khi sinh lại toàn bộ caption.

Artifact thử nằm trong `benchmark_results/caption_v2/`. Caption V1 nguồn được dùng
làm đối chứng. Kết quả và giới hạn được ghi trong `CAPTION_V2_EVALUATION.md`.
